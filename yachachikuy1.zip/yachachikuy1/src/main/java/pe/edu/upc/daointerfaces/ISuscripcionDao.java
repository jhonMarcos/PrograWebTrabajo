package pe.edu.upc.daointerfaces;

import java.util.List;

import pe.edu.upc.entities.Suscripcion;

public interface ISuscripcionDao {
	public void insert(Suscripcion s);
	public List<Suscripcion> list();
	
	
	public void delete(int id); 
}
