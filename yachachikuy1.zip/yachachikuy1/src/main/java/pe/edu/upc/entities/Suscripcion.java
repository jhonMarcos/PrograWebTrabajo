package pe.edu.upc.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "Suscripcion")
public class Suscripcion {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idSuscripcion;

	@Column(name = "fechaSuscripcion", nullable = false)
	private Date fechaSuscripcion;

	@Column(name = "estadoSuscripcion", nullable = false, length = 46)
	private String estadoSuscripcion;


	
	
	public Suscripcion() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Suscripcion(int idSuscripcion, Date fechaSuscripcion, String estadoSuscripcion) {
		super();
		this.idSuscripcion = idSuscripcion;
		this.fechaSuscripcion = fechaSuscripcion;
		this.estadoSuscripcion = estadoSuscripcion;
	}



	public int getIdSuscripcion() {
		return idSuscripcion;
	}



	public void setIdSuscripcion(int idSuscripcion) {
		this.idSuscripcion = idSuscripcion;
	}



	public Date getFechaSuscripcion() {
		return fechaSuscripcion;
	}



	public void setFechaSuscripcion(Date fechaSuscripcion) {
		this.fechaSuscripcion = fechaSuscripcion;
	}



	public String getEstadoSuscripcion() {
		return estadoSuscripcion;
	}



	public void setEstadoSuscripcion(String estadoSuscripcion) {
		this.estadoSuscripcion = estadoSuscripcion;
	}
	
	
}
