package pe.edu.upc.daoimpls;


import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import pe.edu.upc.daointerfaces.ISuscripcionDao;
import pe.edu.upc.entities.Suscripcion;

@Transactional
public class SuscripcionImpl implements ISuscripcionDao {
	@PersistenceContext(unitName="yachachikuy1")
	private EntityManager em;

	@Override
	public void insert(Suscripcion p) {

		try {
			em.persist(p);
		} catch (Exception e) {

			System.out.println("Error al insertar suscripcion en el DAO");
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Suscripcion> list() {
		List<Suscripcion> listaSuscripciones = new ArrayList<Suscripcion>();
		try {
			Query jpql = em.createQuery("from Suscripcion p");
			listaSuscripciones = (List<Suscripcion>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println("Error al listar suscripcion en DAO");
		}
		return listaSuscripciones;
	}

	@Transactional
	@Override
	public void delete(int id) {
		try {

			Suscripcion sus = em.find(Suscripcion.class, id);
			em.remove(sus);
			
		} catch (Exception e) {
			System.out.println("Error al eliminar suscripcion en DAO");
		}

	}

}


