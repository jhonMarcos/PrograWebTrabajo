package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import pe.edu.upc.entities.Suscripcion;
import pe.edu.upc.serviceinterfaces.ISuscripcionService;

@Named
@RequestScoped
public class SuscripcionController {

	@Inject
	private ISuscripcionService sService;

	// atributos

	private Suscripcion s;
	private List<Suscripcion> listaSuscripciones;

	// Inicializar
	@PostConstruct
	public void init() {
		this.listaSuscripciones = new ArrayList<Suscripcion>();
		this.s = new Suscripcion();
		this.list();
	}

	// M�todos para atender peticiones

	public String newSuscripcion() {
		this.setP(new Suscripcion());
		return "suscripcion.xhtml";
	}

	public void insert() {
		try {
			sService.insert(s);

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al insertar en el service" + e.getStackTrace());
		}

	}

	public void list() {
		try {
			listaSuscripciones = sService.list();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al listar en el controller");
		}
	}

	public void delete(Suscripcion sus) {
		try {

			sService.delete(sus.getIdSuscripcion());
			this.list();

		} catch (Exception e) {
			System.out.println("Error al eliminar en el controlador de persona");
		}
	}

	// getters & setters
	public Suscripcion getP() {
		return s;
	}

	public void setP(Suscripcion s) {
		this.s = s;
	}

	public List<Suscripcion> getListaSuscripciones() {
		return listaSuscripciones;
	}

	public void setListaSuscripciones(List<Suscripcion> listaSuscripciones) {
		this.listaSuscripciones = listaSuscripciones;
	}

}
